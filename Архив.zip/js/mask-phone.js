$(function () {
	$('.contact-form__input_tel').mask('+7 (000) 000-00-00');
});
